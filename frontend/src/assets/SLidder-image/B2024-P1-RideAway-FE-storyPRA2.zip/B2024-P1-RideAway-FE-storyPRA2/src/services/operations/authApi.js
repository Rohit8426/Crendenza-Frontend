import toast from "react-hot-toast";
import { setLoading, setToken } from "../../slices/authSlice";
import { setUser } from "../../slices/profileSlice";
import { endpoints } from "../apis";
import { apiconnector } from "../apiconnector";

const { SIGNUP_API, LOGIN_API, SENDOTP_API } = endpoints;

// send otp
export function sendOtp(
  phoneNumber,
  navigate,
  setWarning,
  isLogin = false,
  setOtpSent = null
) {
  return async (dispatch) => {
    const toastId = toast.loading("Loading...");
    dispatch(setLoading(true));

    try {
      console.log("ISLOGIN --> ", isLogin);
      const response = await apiconnector("POST", SENDOTP_API, {
        phoneNumber,
        isLogin,
      });

      console.log("SENDOTP API RESPONSE ---> ", response);

      if (!response.data.success) {
        throw new Error(response.data.message);
      }

      toast.success("OTP sent successfully");

      isLogin ? setOtpSent((prev) => !prev) : navigate("/verify-otp");
    } catch (error) {
      console.log("SENDOTP API ERROR............", error);
      setWarning(error.response.data.message);
      toast.error("Could Not Send OTP");
    }

    dispatch(setLoading(false));
    toast.dismiss(toastId);
  };
}

// sign up
export function signup(
  firstName,
  lastName,
  email,
  phoneNumber,
  otp,
  navigate,
  setWarning
) {
  return async (dispatch) => {
    const toastId = toast.loading("Loading...");
    dispatch(setLoading(true));

    try {
      const response = await apiconnector("POST", SIGNUP_API, {
        firstName,
        lastName,
        email,
        phoneNumber,
        otp,
      });

      console.log("SIGNUP API RESPONSE ---> ", response);

      if (!response.data.success) {
        throw new Error(response.data.message);
      }

      toast.success("Signup successfully");
      navigate("/login");
    } catch (error) {
      console.log("SIGNUP API ERROR............", error);
      setWarning(error.response.data.message);
      toast.error("Try again after some time!");
    }

    dispatch(setLoading(false));
    toast.dismiss(toastId);
  };
}

// login
export function login(phoneNumber, otp, navigate, setWarning) {
  return async (dispatch) => {
    const toastId = toast.loading("Loading...");
    dispatch(setLoading(true));

    try {
      const response = await apiconnector("POST", LOGIN_API, {
        phoneNumber,
        otp,
      });

      console.log("LOGIN API RESPONSE ---> ", response);

      if (!response.data.success) {
        console.log("Warning..");

        throw new Error(response.data.message);
      }

      toast.success("Login successful");

      dispatch(setToken(response.data.token));
      dispatch(setUser(response.data.user));

      localStorage.setItem("token", JSON.stringify(response.data.token));
      localStorage.setItem("user", JSON.stringify(response.data.user));

      navigate("/dashboard/my-profile");
    } catch (error) {
      console.log("LOGIN API ERROR............", error);
      setWarning(error.response.data.message);
      toast.error("Try again after some time!");
    }
    dispatch(setLoading(false));
    toast.dismiss(toastId);
  };
}
