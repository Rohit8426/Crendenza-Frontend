export const reviews = [
  {
    name: "Vartika Kushwah",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam urna, vulputate nec sagittis at, lobortis non justo. Donec vitae lectus condimentum, commodo neque quis, condimentum augue. Etiam hendrerit mauris et mi malesuada suscipit. In gravida luctus sem, vel rhoncus ante finibus nec.",
  },
  {
    name: "Ayan Khan",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam urna, vulputate nec sagittis at, lobortis non justo. Donec vitae lectus condimentum, commodo neque quis, condimentum augue. Etiam hendrerit mauris et mi malesuada suscipit. In gravida luctus sem, vel rhoncus ante finibus nec.",
  },
  {
    name: "Mayank Ojha",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam urna, vulputate nec sagittis at, lobortis non justo. Donec vitae lectus condimentum, commodo neque quis, condimentum augue. Etiam hendrerit mauris et mi malesuada suscipit. In gravida luctus sem, vel rhoncus ante finibus nec.",
  },
  {
    name: "Narendra Dhakad",
    review:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed diam urna, vulputate nec sagittis at, lobortis non justo. Donec vitae lectus condimentum, commodo neque quis, condimentum augue. Etiam hendrerit mauris et mi malesuada suscipit. In gravida luctus sem, vel rhoncus ante finibus nec.",
  },
];
