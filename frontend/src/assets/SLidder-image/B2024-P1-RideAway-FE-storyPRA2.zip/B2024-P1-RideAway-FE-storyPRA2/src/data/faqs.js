export const faqs = [
  {
    tag: "General",
    quesions: [
      "How can i rent a bike?",
      "How To Extend My Trip Date After?",
      "How To Extend My Trip?",
      "Am I Responsible For Fuel?",
      "Can I Book A Bike Under 20 Year Of Age",
      "How Can I Apply For Promo Code?",
    ],
  },
  {
    tag: "Security",
    quesions: [
      "How do i track my bike?",
      "How To Extend My Trip Date After?",
      "How To Extend My Trip?",
      "Am I Responsible For Fuel?",
      "Can I Book A Bike Under 20 Year Of Age",
      "How Can I Apply For Promo Code?",
    ],
  },
  {
    tag: "Booking",
    quesions: [
      "How Do I Find A Bike For Trip?",
      "How To Extend My Trip Date After?",
      "How To Extend My Trip?",
      "Am I Responsible For Fuel?",
      "Can I Book A Bike Under 20 Year Of Age",
      "How Can I Apply For Promo Code?",
    ],
  },
  {
    tag: "Payment",
    quesions: [
      "Is my payment secure?",
      "How To Extend My Trip Date After?",
      "How To Extend My Trip?",
      "Am I Responsible For Fuel?",
      "Can I Book A Bike Under 20 Year Of Age",
      "How Can I Apply For Promo Code?",
    ],
  },
  {
    tag: "Others",
    quesions: [
      "How to find my location?",
      "How To Extend My Trip Date After?",
      "How To Extend My Trip?",
      "Am I Responsible For Fuel?",
      "Can I Book A Bike Under 20 Year Of Age",
      "How Can I Apply For Promo Code?",
    ],
  },
];
