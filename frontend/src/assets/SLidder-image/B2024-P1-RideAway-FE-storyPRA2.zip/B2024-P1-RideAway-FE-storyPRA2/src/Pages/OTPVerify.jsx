import React, { useState } from "react";
import { GiAnticlockwiseRotation } from "react-icons/gi";
import { sendOtp, signup } from "../services/operations/authApi";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

function OTPVerify() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [warning, setWarning] = useState("");
  const { signupData } = useSelector((state) => state.auth);

  const [otp, setOtp] = useState("");

  function onSubmitHanler(e) {
    const { firstName, lastName, phoneNumber, email } = signupData;
    dispatch(
      signup(firstName, lastName, email, phoneNumber, otp, navigate, setWarning)
    );
  }

  return (
    <div className="w-full h-full bg-white flex justify-center items-center">
      <div className="lg:w-7/12 w-[90%] bg-[#f8f8f8] rounded-lg flex flex-col justify-center items-center p-8 lg:p-16 gap-6 h-[70%]">
        <div className="w-full max-w-[30rem] flex flex-col gap-1 items-start justify-between mb-5">
          <div className="text-3xl font-semibold text-left leading-9">
            OTP Verification
          </div>
          <p className="text-sm">
            We have sent an sms on your mobile number {"XXXXXXXXXX"}. Please
            check your phone and enter otp.
          </p>
        </div>

        <div className="w-full max-w-[30rem] flex flex-col gap-1 items-start justify-between">
          <label htmlFor="otp" className="text-base font-medium">
            Enter OTP<sup className="text-red-500">*</sup>{" "}
          </label>
          <input
            required
            type="text"
            name="otp"
            id="otp"
            placeholder="Enter otp"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            className="w-full px-4 py-2 rounded-l-md text-base outline-none bg-[#d9d9d9]/50"
          />
        </div>

        {warning !== "" && (
          <p className="text-center text-sm text-red-500 -mt-5">{warning}</p>
        )}

        <div className="w-full flex flex-col justify-between items-center gap-2 max-w-[30rem]">
          <button
            className="sm:p-4 px-4 py-3 w-full bg-black text-white rounded-lg text-xl font-medium md:hover:scale-95 transition-trasnform duration-200"
            onClick={onSubmitHanler}
          >
            Verify
          </button>
          <div
            className="flex flex-row justify-center gap-1 items-center text-[0.875rem] text-blue-400 max-w-max"
            onClick={() => dispatch(sendOtp(signupData.phoneNumber, navigate))}
          >
            <GiAnticlockwiseRotation fontSize={18} /> <span>Resend</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OTPVerify;
