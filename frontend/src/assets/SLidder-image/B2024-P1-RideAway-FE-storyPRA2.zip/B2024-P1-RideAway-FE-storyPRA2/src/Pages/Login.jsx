import { useState } from "react";
import loginImg from "../assets/images/LoginImage.svg";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { login, sendOtp } from "../services/operations/authApi";
import { useDispatch, useSelector } from "react-redux";
import { validatePhone } from "../utils/validation";
import toast from "react-hot-toast";
import { GiAnticlockwiseRotation } from "react-icons/gi";

function Login({ setIsClicked }) {
  const { loading } = useSelector((state) => state.auth);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();

  const [loginField, setLoginField] = useState("");
  const [warning, setWarning] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);

  const submitHandler = (e) => {
    e.preventDefault();

    if (warning !== "") setWarning("");

    if (!validatePhone(loginField)) {
      toast.error("Enter a valid phone number");
      setWarning("Invalid email or phonenumber");
      return;
    }

    dispatch(sendOtp(loginField, navigate, setWarning, true, setOtpSent));
  };

  const loginSubmitHandler = (e) => {
    e.preventDefault();
    if (warning !== "") setWarning("");
    dispatch(login(loginField, otp, navigate, setWarning));
  };

  return (
    <>
      <div className="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center w-full z-[100] backdrop-blur-md overflow-hidden">
        <div className="relative lg:w-9/12 w-[90%] bg-[#F8F8F8] rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-8 px-8 py-14 lg:p-16">
          {!location.pathname.endsWith("/login") && (
            <span
              onClick={() => setIsClicked(false)}
              className="absolute top-6 right-6 cursor-pointer"
            >
              ❌
            </span>
          )}

          <div className="hidden md:flex justify-center items-center md:w-[50%] border-r border-black/40">
            <img
              src={loginImg}
              className="hidden md:inline w-full"
              alt="Girl in a jacket"
            ></img>
          </div>

          {loading ? (
            <div className="flex gap-5 w-full md:w-[50%] justify-center">
              <div className="loader"></div>
            </div>
          ) : (
            <div className="flex flex-col gap-5 w-full md:w-[50%] justify-between">
              <h3 className="font-semibold text-4xl text-black">Login</h3>

              <form
                onSubmit={otpSent ? loginSubmitHandler : submitHandler}
                className="w-full flex flex-col justify-between items-start gap-5"
              >
                <div className="flex flex-col justify-start gap-1 w-full">
                  <label htmlFor="loginField">
                    {otpSent ? "Otp" : "Phone or email"}
                    <sup className="text-red-500">*</sup>
                  </label>
                  <input
                    required
                    type="text"
                    name="loginField"
                    className="p-4 rounded-lg bg-[#d9d9d9]/50 outline-none"
                    placeholder={otpSent ? "Enter otp" : "Enter phone or email"}
                    value={otpSent ? otp : loginField}
                    onChange={(e) =>
                      otpSent
                        ? setOtp(e.target.value)
                        : setLoginField(e.target.value)
                    }
                  />
                  {warning !== "" && (
                    <p className="text-center text-sm text-red-500">
                      {warning}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full rounded-lg bg-black text-white font-medium text-xl lg:p-4 px-4 py-3 cursor-pointer text-center duration-200 transition-transform hover:scale-95"
                >
                  {otpSent ? "Verify" : "Login"}
                </button>

                {otpSent ? (
                  <div
                    className="w-full -mt-3 flex flex-row justify-center gap-1 items-center text-[0.875rem] text-blue-400"
                    onClick={() =>
                      dispatch(sendOtp(loginField, navigate, true))
                    }
                  >
                    <GiAnticlockwiseRotation fontSize={18} />{" "}
                    <span>Resend</span>
                  </div>
                ) : null}

                {otpSent ? null : (
                  <div className="w-full">
                    <p className="text-center font-normal text-sm">
                      Don’t have an account ?
                    </p>
                    <Link to={"/signup"}>
                      <div className="rounded-lg bg-[#62B91D] text-white font-medium text-xl px-4 py-3 lg:p-4 cursor-pointer text-center duration-200 transition-transform hover:scale-95">
                        Register
                      </div>
                    </Link>
                  </div>
                )}
              </form>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
export default Login;
