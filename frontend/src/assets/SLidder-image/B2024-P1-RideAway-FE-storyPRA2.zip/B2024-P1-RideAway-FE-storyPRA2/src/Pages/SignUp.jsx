import { useState } from "react";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { setSignupData } from "../slices/authSlice";
import { sendOtp } from "../services/operations/authApi";
import { validatePhone, validateEmail } from "../utils/validation";

const SignUp = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [userWarning, setUserWarning] = useState("");
  const [emailWarning, setEmailWarning] = useState("");
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
  });

  const onChangeHandler = (e) => {
    // console.log(e.target);
    const { name, value } = e.target;

    setFormData((prev) => {
      return {
        ...prev,
        [name]: value,
      };
    });
  };

  const submitHandler = (e) => {
    e.preventDefault();

    if (!validateEmail(formData.email)) {
      setEmailWarning("Enter a valid email");
      return;
    }

    if (!validatePhone(formData.phoneNumber)) {
      setUserWarning("Enter a valid phone number");
    }

    // set signup data
    dispatch(setSignupData(formData));

    // send otp
    dispatch(sendOtp(formData.phoneNumber, navigate, setUserWarning));

    // RESET DATA
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
    });
  };

  return (
    <div className="w-full h-full bg-white flex justify-center items-center">
      <div className="lg:w-7/12 w-[90%] bg-[#F8F8F8] rounded-lg flex flex-col justify-start p-8 lg:p-16 gap-4">
        <div className="flex flex-col justify-between items-start">
          <h3 className="text-4xl text-black font-semibold">RideAway</h3>
          <p>Create an Account</p>
        </div>

        <form
          onSubmit={submitHandler}
          className="w-full flex justify-between items-start flex-col gap-3 lg:gap-5"
        >
          <div className="w-full flex flex-col lg:flex-row gap-3 md:gap-5 justify-between">
            <div className="flex flex-col justify-start gap-1 w-full lg:w-[50%]">
              <label htmlFor="firstName">
                First Name <sup className="text-red-500">*</sup>
              </label>
              <input
                required
                id="firstName"
                name="firstName"
                type="text"
                value={formData.firstName}
                className="p-4 rounded-lg bg-[#d9d9d9]/50 outline-none"
                autoComplete="none"
                onChange={onChangeHandler}
              />
            </div>

            <div className="flex flex-col justify-start gap-1 w-full lg:w-[50%]">
              <label htmlFor="lastName">
                Last Name <sup className="text-red-500">*</sup>
              </label>
              <input
                required
                autoComplete="none"
                name="lastName"
                id="lastName"
                onChange={onChangeHandler}
                value={formData.lastName}
                className="p-4 rounded-lg bg-[#d9d9d9]/50 outline-none"
              ></input>
            </div>
          </div>

          <div className="w-full flex flex-col gap-1">
            <label htmlFor="email">
              Email <sup className="text-red-500">*</sup>
            </label>
            <input
              required
              name="email"
              id="email"
              type="email"
              className="p-4 rounded-lg bg-[#d9d9d9]/50 outline-none"
              autoComplete="none"
              onChange={onChangeHandler}
              value={formData.email}
            />
            {emailWarning !== "" && (
              <p className="text-center text-sm text-red-500">{emailWarning}</p>
            )}
          </div>

          <div className="w-full flex flex-col gap-1">
            <label htmlFor="email">
              Phone <sup className="text-red-500">*</sup>
            </label>
            <input
              required
              name="phoneNumber"
              id="phoneNumber"
              type="text"
              minLength={10}
              maxLength={10}
              className="p-4 rounded-lg bg-[#d9d9d9]/50 outline-none"
              autoComplete="none"
              onChange={onChangeHandler}
              value={formData.phoneNumber}
            />
            {userWarning !== "" && (
              <p className="text-center text-sm text-red-500">{userWarning}</p>
            )}
          </div>

          <div className="flex flex-col justify-center gap-2 w-full mt-2">
            <button
              type="submit"
              className="sm:p-4 px-4 py-3 w-full bg-black text-white rounded-lg text-xl font-medium md:hover:scale-95 transition-transform duration-200"
            >
              Register
            </button>

            <Link to={"/login"} className="mx-auto">
              <p className="text-sm font-light text-blue-500 text-center hover:text-blue-700 transition-colors duration-200">
                Already have an account?
              </p>
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
