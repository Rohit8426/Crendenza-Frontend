import Header from "../components/core/HomePage/header";
import Feature from "../components/core/HomePage/feature";
import RentaBike from "../components/core/HomePage/rentAbike";
import Footer from "../components/common/Footer";
import FAQs from "../components/core/HomePage/FAQs";
import Reviews from "../components/core/HomePage/Reviews";
import { HeroSection } from "../components/core/HomePage/HeroSection";
import SearchLocation from "../components/core/HomePage/SerachLocation";
import { useState } from "react";
import Login from "./Login";
const Home = () => {
  const [isClicked, setIsClicked] = useState(false);

  return (
    <div
      className={`w-full h-full relative ${
        isClicked ? "overflow-hidden" : "overflow-x-hidden"
      }`}
    >
      <Header setIsClicked={setIsClicked} />
      <HeroSection />
      <SearchLocation />
      <Feature />
      <RentaBike />
      {/* <Reviews /> */}
      <FAQs />
      <Footer />

      {isClicked && <Login setIsClicked={setIsClicked} />}
    </div>
  );
};
export default Home;
