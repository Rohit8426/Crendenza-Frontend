const SearchLocation = () => {
  return (
    <div className="w-full md:w-10/12 bg-white mx-auto flex flex-col flex-wrap sm:flex-row justify-between items-end gap-2 text-2xl rounded-xl md:border border-gray-300 shadow-md p-8 md:p-12 md:-mt-20 mt-4 ">
      <div className="flex flex-col gap-1 w-full sm:w-[20%]">
        <label htmlFor="location" className="font-semibold text-[1.5rem]">
          Location
        </label>
        <select
          id="location"
          className="rounded-lg border-2 border-gray-300 px-3 pr-4 py-2 w-full outline-none"
        >
          <option>Select Location</option>
          <option>Shivpuri</option>
          <option>Gwalior</option>
          <option>Guna</option>
        </select>
      </div>

      <div className="flex flex-col gap-1 w-full sm:w-[20%]">
        <label htmlFor="pickup" className="font-semibold text-[1.5rem]">
          Pick Up
        </label>
        <select
          id="pickup"
          className="rounded-lg border-2 border-gray-300 px-3 pr-4 py-2 w-full outline-none"
        >
          <option>Select Location</option>
          <option value={"shivpuri"}>Shivpuri</option>
          <option>Gwalior</option>
          <option>Guna</option>
        </select>
      </div>

      <div className="flex gap-1 flex-col w-full  sm:w-[20%]">
        <label htmlFor="date" className="font-semibold text-[1.5rem]">
          Date
        </label>
        <input
          type="date"
          id="date"
          className="rounded-lg border-2 border-gray-300 px-3 pr-4 py-2 w-full outline-none"
        ></input>
      </div>

      <button className="border-black px-4 py-2 bg-black text-[1.5rem] leading-9 text-white rounded-lg w-full sm:w-[20%]">
        Rent Now
      </button>
    </div>
  );
};

export default SearchLocation;
