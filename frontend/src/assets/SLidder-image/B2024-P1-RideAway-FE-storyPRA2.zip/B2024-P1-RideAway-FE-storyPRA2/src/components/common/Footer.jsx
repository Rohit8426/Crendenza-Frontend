import {
  FaFacebook,
  FaXTwitter,
  FaInstagram,
  FaLinkedin,
} from "react-icons/fa6";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="flex flex-row bg-black text-white justify-center items-center p-4 sm:px-5 sm:py-10">
      <div className="w-11/12 max-w-[1260px] mx-auto flex flex-col sm:flex-row flex-wrap gap-6 sm:gap-12 justify-between items-start">
        <div className="flex flex-col justify-start gap-5">
          <h3 className="font-semibold text-3xl">RideAway</h3>

          <p className="text-white/50 text-[1rem] leading-5 -mt-3">
            <span>is just a RidwAway </span> <br />
            <span>Take control of your ride.</span>{" "}
          </p>

          <div className="flex flex-row justify-between items-center gap-2 text-[24px]">
            <Link to={"/facebook"}>
              <FaFacebook />
            </Link>

            <Link to={"/instagram"}>
              <FaInstagram />
            </Link>

            <Link to={"/twitter"}>
              <FaXTwitter />
            </Link>

            <Link to={"/linkedin"}>
              <FaLinkedin />
            </Link>
          </div>
        </div>

        <div className="flex flex-col justify-start gap-2">
          <p className="text-xl font-semibold">About Company</p>
          <div className="flex flex-col justify-start gap-[2px]">
            <Link to={"/about"}>
              <p>About us</p>
            </Link>
            <Link to={"/career"}>
              <p>Career</p>
            </Link>
            <Link to={"/help"}>
              <p>Help</p>
            </Link>
            <Link to={"contact-us"}>
              <p>Contact us</p>
            </Link>
            <Link to={"/privacy-policy"}>
              {" "}
              <p>Privacy Policy</p>
            </Link>
            <Link to={"/term-and-conditions"}>
              <p>Terms and conditions</p>
            </Link>
          </div>
        </div>

        <div className="flex flex-col justify-start gap-2">
          <p className="font-semibold text-xl">City</p>
          <ul className="list-disc flex flex-col justify-start ml-4">
            <li> Shivpuri</li>
            <li> Gwalior</li>
            <li> Guna</li>
            <li> Jhansi</li>
            <li> Pune</li>
          </ul>
        </div>

        <div className="flex flex-col justify-start gap-2">
          <p className="font-semibold text-xl">Vehicle Types</p>
          <ul className="list-disc flex flex-col justify-start ml-4">
            <li> Electric Scooter </li>
            <li> Electric Bike</li>
            <li> Bike</li>
            <li> Scooty</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Footer;
