import feature from "../../../assets/images/SmallVehicle.svg";

const Feature = () => {
  return (
    <div className="w-full md:w-11/12 md:max-w-[1260px] mx-auto flex flex-col md:flex-row bg-white justify-start items-center gap-10 py-10 md:py-14">
      {/* section 1 */}
      <div className="bg-white flex flex-col items-start gap-8 w-full md:w-[50%] p-8 px-10">
        <h3 className="text-5xl font-bold text-black leading-[50px]">
          Rent A Bike
        </h3>
        <div className="flex flex-row flex-wrap items-center justify-start gap-4">
          <div className="border border-black rounded-lg px-4 py-1 font-medium text-xl bg-orange-50">
            Luxary
          </div>
          <div className="border border-black rounded-lg px-4 py-1 font-medium text-xl bg-orange-50">
            Comfort
          </div>
          <div className="border border-black rounded-lg px-4 py-1 font-medium text-xl bg-orange-50">
            Prestige
          </div>
        </div>
        <p className="font-normal text-2xl text-black text-justify">
          Booking a bike with us is simple and easy.You can browse our selection
          of vehicles online,choose the bike that best fits your needs,and book
          it for the duration of your choice.Our user friendly platorm allows
          you to manage your booking and view your trip history with ease.
        </p>
      </div>

      {/* section 2 */}
      <div className="w-full md:w-[50%]">
        <img src={feature} alt="hey "></img>
      </div>
    </div>
  );
};

export default Feature;
