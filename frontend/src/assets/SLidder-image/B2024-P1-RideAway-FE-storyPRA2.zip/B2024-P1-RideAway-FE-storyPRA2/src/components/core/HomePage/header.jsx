const Header = ({ setIsClicked }) => {
  return (
    <div className="w-full flex items-center justify-center bg-[#080707] text-white h-16">
      <div className="w-full md:w-11/12 max-w-[1280px] mx-auto flex flex-row items-center justify-between p-2 sm:px-4 sm:pt-12">
        <h1 className="text-3xl sm:text-4xl font-semibold leading-[44px]">
          RideAway
        </h1>
        <button
          onClick={() => setIsClicked(true)}
          className="sm:inline mr-1 px-5 py-2 text-base leading-5 sm:leading-6 border-2 border-white rounded-lg hover:scale-95 hover:text-black hover:bg-white transition-all duration-200 font-medium"
        >
          Login
        </button>
      </div>
    </div>
  );
};

export default Header;
