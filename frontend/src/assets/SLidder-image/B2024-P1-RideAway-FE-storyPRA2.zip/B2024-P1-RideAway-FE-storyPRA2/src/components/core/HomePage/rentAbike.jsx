import rentAbike from "../../../assets/images/KidPerforming.svg";
import { Link } from "react-router-dom";

const RentaBike = () => {
  return (
    <div className="w-full md:w-11/12 md:max-w-[1260px] mx-auto flex flex-col md:flex-row bg-white justify-start items-center gap-10 py-10 md:py-14">
      <div className="w-full md:w-[50%] p-5">
        <img src={rentAbike} alt="hey"></img>
      </div>

      <div className="bg-white flex flex-col items-start gap-8 w-full md:w-[50%] p-8 rounded-lg shadow-lg shadow-blue-200">
        <h3 className="text-4xl font-bold text-black leading-[50px]">
          Do you want to share your vehicle?
        </h3>

        <p className="font-normal text-2xl text-black text-justify">
          We'll use your Location to Calculate your onboard bonus.Each zip code
          will belong to one of five zones. Zones are based on guest demands for
          bikes more guest demands means a higher zone, and bigger bonuses for
          bikes.Zones 4 and 5 aren't eligible for the onboard bonus.
        </p>

        <Link to={"/share-vehicle"}>
          <button className=" bg-black text-white rounded-lg p-3 px-10 font-medium text-lg">
            Share Now
          </button>
        </Link>
      </div>
    </div>
  );
};

export default RentaBike;
