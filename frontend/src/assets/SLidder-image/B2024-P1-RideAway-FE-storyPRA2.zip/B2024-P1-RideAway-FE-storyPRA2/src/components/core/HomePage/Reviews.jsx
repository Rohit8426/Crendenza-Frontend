import { reviews } from "../../../data/reviews";

const Reviews = () => {
  return (
    <div className="w-11/12 max-w-[1260px] mx-auto bg-[#f8f8f8] p-12 ">
      <h1 className="font-bold text-5xl mb-12">See what our Customers say?</h1>
      <div className="flex gap-10 ">
        {reviews.map((el, index) => {
          return (
            <div key={index} className="text-sm">
              {el.name}
              <br></br>
              <br />
              {el.review}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Reviews;
