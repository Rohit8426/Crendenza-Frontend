import React, { useState, Fragment } from "react";
import { faqs } from "../../../data/faqs";
import Question from "./Questions";

function FAQs() {
  const [currentTab, setCurrentTab] = useState(
    faqs[Math.floor(faqs.length / 2)].tag
  );

  return (
    <div className="my-10 mx-auto w-full md:w-11/12 max-w-[1260px] rounded-xl bg-[#f8f8f8] p-11 flex justify-center items-center">
      <div className="flex flex-col items-center">
        <h2 className="text-center text-3xl font-semibold">FAQs</h2>

        <div className="w-full flex justify-center items-center md:gap-7 gap-2 mt-3 text-xl flex-wrap">
          {faqs.map((el, index) => (
            <div
              key={index}
              className={`px-2 py-2 rounded-lg text-xl ${
                currentTab === el.tag
                  ? "bg-[#d9d9d9] text-black font-medium"
                  : "font-normal text-gray-500"
              }`}
              onClick={() => setCurrentTab(el.tag)}
            >
              {el.tag}
            </div>
          ))}
        </div>

        {faqs.map((el, index) => {
          return (
            <Fragment key={index}>
              {el.tag === currentTab ? (
                <div className="w-full my-7 flex flex-row flex-wrap justify-center items-center gap-7 mx-auto">
                  {el.quesions.map((ques, index) => (
                    <Question ques={ques} key={index} />
                  ))}
                </div>
              ) : (
                <></>
              )}
            </Fragment>
          );
        })}
      </div>
    </div>
  );
}

export default FAQs;
