import bike from "../../../assets/images/Bikeimg.svg";

export const HeroSection = () => {
  return (
    <div className="w-full bg-black px-2 py-4 sm:p-8 md:p-12 lg:p-16 flex justify-center items-center">
      <div className="w-full lg:w-11/12 max-w-[1260px] text-white flex justify-between items-center py-8 gap-8">
        <div className="flex flex-col justify-between items-start gap-8">
          <h1 className="font-semibold text-6xl">
            Unlock Endless Driving With RideAway
          </h1>
          <p className="text-2xl opacity-70">
            To contribute to positive change and achieve our sustainability goal
            with many extraordinary
          </p>
        </div>
        <img src={bike} className="hidden md:inline w-[40%] lg:w-[50%]"></img>
      </div>
    </div>
  );
};
