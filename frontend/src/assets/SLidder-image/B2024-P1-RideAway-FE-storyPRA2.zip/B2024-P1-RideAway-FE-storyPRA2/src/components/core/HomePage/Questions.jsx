import React from "react";

function Question({ ques }) {
  return (
    <div className="w-[100%] sm:w-[40%] text-lg font-normal border-2 border-black/20 text-center p-2 rounded-md">
      {ques}
    </div>
  );
}

export default Question;
