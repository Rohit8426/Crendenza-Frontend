export const validatePhone = (phone) => {
  const regex = /^\+?(\d[\d-. ]?){7,14}\d$/;
  return regex.test(phone);
};

export const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};
