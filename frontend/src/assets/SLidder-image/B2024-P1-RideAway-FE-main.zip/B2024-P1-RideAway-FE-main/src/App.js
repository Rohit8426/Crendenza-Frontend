import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div>App</div>
      </header>
    </div>
  );
}

export default App;
